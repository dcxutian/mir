

#ifndef __ORZ_DATA_TYPE__
#define __ORZ_DATA_TYPE__


typedef unsigned char byte;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef unsigned long ulong;


#endif