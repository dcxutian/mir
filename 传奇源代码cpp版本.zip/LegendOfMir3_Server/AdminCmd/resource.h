//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AdminCmd.rc
//
#define IDS_COMMAND_MONGEN              1
#define IDS_COMMAND_INSPECTOR           2
#define IDS_COMMAND_ADMIN               3
#define IDS_COMMAND_INVINCIBILITY       4
#define IDS_COMMAND_ATTACK              5
#define IDS_COMMAND_MOVE                6
#define IDS_COMMAND_CHANGELEVEL         7
#define IDS_COMMAND_MOVEFREESTYLE       8
#define IDS_COMMAND_MAP                 9
#define IDS_COMMAND_LEVEL               10
#define IDS_COMMAND_MONLEVEL            11
#define IDS_COMMAND_RECALL              12
#define IDS_COMMAND_NUMOFMON            13
#define IDS_COMMAND_NUMOFHUMAN          14
#define IDS_COMMAND_SABUKMONEY          15
#define IDS_COMMAND_KICK                16
#define IDS_COMMAND_KICK2               17
#define IDS_COMMAND_TING                18
#define IDS_COMMAND_KINGTING            19
#define IDS_COMMAND_LUCKYVALUE          20
#define IDS_COMMANT_SHUTUP              21
#define IDS_COMMAND_TALK                22
#define IDS_COMMAND_SHUTUPMAN           23
#define IDS_COMMAND_RELOADADMIN         24
#define IDS_COMMAND_RELOADABUSIVE       25
#define IDS_COMMAND_MOOTAEBO            26
#define IDS_COMMAND_BACKWALK            27
#define IDS_COMMAND_GAIN                28
#define IDS_COMMAND_DELGOLD             29
#define IDS_COMMAND_ADDGOLD             30
#define IDS_COMMAND_GOOD                31
#define IDS_COMMAND_OTHERDELGOLD        32
#define IDS_COMMAND_OTHERADDGOLD        33
#define IDS_COMMAND_OTHERLEVELUP        34
#define IDS_COMMAND_OTHEREXPUP          35
#define IDS_COMMAND_WEAPONDUR           36
#define IDS_COMMAND_PARDON              37
#define IDS_COMMAND_PKPOINT             38
#define IDS_COMMAND_PKPOINTUP           39
#define IDS_COMMAND_CHANGELUCKY         40
#define IDS_COMMAND_SKILLUP             41
#define IDS_COMMAND_OTHERSKILLUP        42
#define IDS_COMMAND_DELSKILL            43
#define IDS_COMMAND_OTHERDELSKILL       44
#define IDS_COMMAND_CHGJOB              45
#define IDS_COMMAND_CHGGENDER           46
#define IDS_COMMAND_COLOR               47
#define IDS_COMMAND_MONRECALL           48
#define IDS_COMMAND_MISSION             49
#define IDS_COMMAND_GENPOS              50
#define IDS_COMMAND_TRANSPARENCY        51
#define IDS_COMMAND_CIVILWAR            52
#define IDS_COMMAND_DYEINGHAIR          53
#define IDS_COMMAND_DYEINGWEAR          54
#define IDS_COMMAND_SUSINOTICE          55
#define IDS_COMMAND_GAMCHUNG            56
#define IDS_COMMAND_CHOOLDOO            57
#define IDS_COMMAND_RESERVED1           58
#define IDS_COMMAND_RESERVED2           59
#define IDS_COMMAND_RESERVED3           60
#define IDS_COMMAND_RESERVED4           61
#define IDS_COMMAND_RESERVED5           62
#define IDS_COMMAND_RESERVED6           63
#define IDS_COMMAND_RESERVED7           64
#define IDS_COMMAND_RESERVED8           65
#define IDS_COMMANT_RESERVED9           66
#define IDS_COMMAND_RESERVED10          67
#define IDS_COMMAND_RESERVED11          68
#define IDS_COMMAND_RESERVED12          69
#define IDS_COMMAND_RESERVED13          70
#define IDS_COMMAND_HAIRSTYLE           71

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        72
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           72
#endif
#endif
