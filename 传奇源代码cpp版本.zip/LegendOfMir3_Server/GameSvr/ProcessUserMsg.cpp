#include "stdafx.h"

#define _MSG_GOOD	"+GOOD/"
#define _MSG_FAIL	"+FAIL/"
