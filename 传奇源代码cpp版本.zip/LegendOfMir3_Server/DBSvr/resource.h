//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DBSvr.rc
//
#define IDS_NOTWINNT                    1
#define IDS_LVS_LABEL1                  2
#define IDS_LVS_LABEL2                  3
#define IDS_LVS_LABEL3                  4
#define IDS_STARTSERVICE                5
#define IDS_STOPSERVICE                 6
#define IDS_CONNECT_LOGINSERVER         7
#define IDS_DISCONNECT_LOGINSERVER      8
#define IDS_PROGRAM_QUIT                9
#define IDS_PROGRAM_TITLE               10
#define IDS_CANT_CONNECT                11
#define IDS_CONFLVS_LABEL1              12
#define IDS_CONFLVS_LABEL2              13
#define IDS_CONFLVS_LABEL3              14
#define IDS_CONFLVS_LABEL4              15
#define IDS_CONFLVS_LABEL5              16
#define IDS_TAB_LABEL1                  17
#define IDS_ACCEPT_GATESERVER           18
#define IDS_OPEN_USER                   19
#define IDS_CLOSE_USER                  20
#define IDS_CONNECTDB                   21
#define IDS_LOADACCOUNTRECORDS          22
#define IDS_BOUNDACCOUNTRECORDS         23
#define IDS_COMPLETENEWUSER             24
#define IDI_MIR2                        101
#define IDR_MAINMENU                    101
#define IDB_TOOLBAR                     102
#define IDD_CONFIGDLG                   104
#define IDC_DBSVR_IP                    1003
#define IDC_DBMS_IP                     1008
#define IDC_DBMS_PORT                   1010
#define IDC_DBMS_ID                     1011
#define IDC_DBMS_PASSWORD               1012
#define IDC_DBMS_DEVICE                 1013
#define IDM_STARTSERVICE                40001
#define IDM_STOPSERVICE                 40002
#define IDM_CONFIG                      40003
#define IDM_EXIT                        40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
