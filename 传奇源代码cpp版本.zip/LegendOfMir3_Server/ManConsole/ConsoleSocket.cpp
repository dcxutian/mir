// ConsoleSocket.cpp : implementation file
//

#include "stdafx.h"
#include "ManConsole.h"
#include "ConsoleSocket.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConsoleSocket

CConsoleSocket::CConsoleSocket()
{
}

CConsoleSocket::~CConsoleSocket()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CConsoleSocket, CAsyncSocket)
	//{{AFX_MSG_MAP(CConsoleSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CConsoleSocket member functions
