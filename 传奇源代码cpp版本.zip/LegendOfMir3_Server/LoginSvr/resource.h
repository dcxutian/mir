//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LoginSvr.rc
//
#define IDS_NOTWINNT                    1
#define IDS_LVS_LABEL1                  2
#define IDS_LVS_LABEL2                  3
#define IDS_LVS_LABEL3                  4
#define IDS_STARTSERVICE                5
#define IDS_STOPSERVICE                 6
#define IDS_CONNECT_LOGINSERVER         7
#define IDS_DISCONNECT_LOGINSERVER      8
#define IDS_PROGRAM_QUIT                9
#define IDS_PROGRAM_TITLE               10
#define IDS_CANT_CONNECT                11
#define IDS_CONFLVS_LABEL1              12
#define IDS_CONFLVS_LABEL2              13
#define IDS_CONFLVS_LABEL3              14
#define IDS_CONFLVS_LABEL4              15
#define IDS_CONFLVS_LABEL5              16
#define IDS_TAB_LABEL1                  17
#define IDS_ACCEPT_GATESERVER           18
#define IDS_OPEN_USER                   19
#define IDS_CLOSE_USER                  20
#define IDS_CONNECTDB                   21
#define IDS_LOADACCOUNTRECORDS          22
#define IDS_BOUNDACCOUNTRECORDS         23
#define IDS_COMPLETENEWUSER             24
#define IDI_ICON1                       101
#define IDI_MIR2                        101
#define IDR_MAINMENU                    101
#define IDM_FONTCOLOR                   101
#define IDB_TOOLBAR                     102
#define IDM_BACKCOLOR                   102
#define IDD_CONFIGDLG                   103
#define IDD_CONFIGDLG_SERVERLIST        104
#define IDD_SVRLIST_ADD                 105
#define IDC_SERVERINFO_LIST             1000
#define IDC_SVRLIST_ADD                 1002
#define IDC_SVRLIST_REMOVE              1003
#define IDC_SVRLIST_EDIT                1004
#define IDC_IPADDRESS1                  1005
#define IDC_IPADDRESS2                  1006
#define IDC_IPADDRESS3                  1007
#define IDC_TITLE                       1009
#define IDC_ADD_GATELIST                1011
#define IDC_GATELIST                    1013
#define IDC_REMOVE_GATELIST             1014
#define IDC_EDIT1                       1016
#define IDC_PORT                        1016
#define IDM_STARTSERVICE                40001
#define IDM_STOPSERVICE                 40002
#define IDM_CONFIG                      40003
#define IDM_EXIT                        40004
#define IDM_SERVERSTAT                  40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
